const replyToMessage=[
    {message:"Hi",reply:"Hello"},
    {message:"kaise ho",reply:"Badhiya"},
    {message:"aur kya ho rha hai",reply:"kuch nhi bas chal rha hai"},
    {message:"kanhan ho",reply:"philhal to ghar pe"},
    {message:"kab aa rhe ho",reply: "abhi to" +new Date()+" hai jald hi aata hoon"},
    {message:"kuch puchna tha",reply:"han batao"},
    {message:"...",reply:"kya"}
];
   
module.exports=replyToMessage;