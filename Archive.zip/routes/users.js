const express = require("express");

const { route } = require("express/lib/application");
var router=express.Router();
// router.use('/',(req,res,next)=>{
//     res.send("Hi in direct route of users");
//     next();
// });

const array=[];
let count=0;
while(count<=10000){
    array.push(count*count);
    count=count+1;

}
router.use('/get',(req,res)=>{
    const resObj={
        status:200,
        data:array,
        message:"mara le bc",
    }
    res.send(resObj);

})
 

module.exports=router;



